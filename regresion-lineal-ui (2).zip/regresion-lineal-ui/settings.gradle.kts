rootProject.name = "regresion-lineal-ui"
